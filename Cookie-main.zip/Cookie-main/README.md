<html>

<head>
<h1>Cookie Cliker Browser</h1>
<p><b>Play Cookie Clicker v2.048 in browser!</b></p>
</head>

<body>
<h1>How to Launch</h1>
<p>1. Download the zip file.</p>
<p>2. Open the zip.</p>
<p>3. Open the index.html file</p>
<p>If you have any issues, contact me at vidio-boy@outlook.com,</p>

<h1>FAQ</h1>
<p>Q: Why is there a .zip inside the .zip?</p>
<p>A: I had all the files for the game saved to my computer, but was too lazy to upload every single file, so I just zipped it and uploaded that instead. (lol)</p>
<p>Q: What version is this compared to the current Cookie Cliker version?</p>
<p>A: This is the current version of Cookie Clicker (as of 4-26-23) 2.048.</p>

<footer><small><b>Disclaimer:</b> I do not own Cookie Clicker, and I am not associated with it in any way, this is just a way for people to access it fullscreen on browser.<small><footer>
</body>

</html>
